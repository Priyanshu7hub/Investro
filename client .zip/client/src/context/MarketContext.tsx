import { createContext, useContext, useState, useMemo } from "react";
import { NIFTY_50_DATA, MOCK_HISTORY_DATA } from "../data/marketData";

interface Stock {
  symbol: string;
  name: string;
  price: number;
  change: number;
}

interface MarketContextType {
  stocks: Stock[];
  marketHistory: { date: string; value: number }[];
  getStock: (symbol: string) => Stock | undefined;
}

const MarketContext = createContext<MarketContextType | undefined>(undefined);

export function MarketProvider({ children }: { children: React.ReactNode }) {
  // Use the REAL NIFTY 50 data from marketData.ts
  const stocks = useMemo(() => NIFTY_50_DATA, []);
  const marketHistory = useMemo(() => MOCK_HISTORY_DATA, []);

  const getStock = (symbol: string) => {
    return stocks.find(s => s.symbol === symbol);
  };

  return (
    <MarketContext.Provider value={{ stocks, marketHistory, getStock }}>
      {children}
    </MarketContext.Provider>
  );
}

export function useMarket() {
  const context = useContext(MarketContext);
  if (context === undefined) {
    throw new Error("useMarket must be used within a MarketProvider");
  }
  return context;
}
