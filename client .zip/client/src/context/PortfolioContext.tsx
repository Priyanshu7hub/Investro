import { createContext, useContext, useState, useEffect } from "react";
import { useAuth } from "./AuthContext";
import { useToast } from "@/hooks/use-toast";

interface Holding {
  symbol: string;
  name: string;
  quantity: number;
  averagePrice: number;
}

interface PortfolioContextType {
  holdings: Holding[];
  buyStock: (symbol: string, name: string, price: number, quantity: number) => void;
  sellStock: (symbol: string, price: number, quantity: number) => void;
  getHolding: (symbol: string) => Holding | undefined;
  totalInvested: number;
  totalCurrentValue: (currentPrices: Record<string, number>) => number;
}

const PortfolioContext = createContext<PortfolioContextType | undefined>(undefined);

export function PortfolioProvider({ children }: { children: React.ReactNode }) {
  const [holdings, setHoldings] = useState<Holding[]>([]);
  const { user } = useAuth();
  const { toast } = useToast();

  // Load portfolio from local storage on auth change
  useEffect(() => {
    if (user) {
      const stored = localStorage.getItem(`investro_portfolio_${user.email}`);
      if (stored) {
        try {
          setHoldings(JSON.parse(stored));
        } catch (e) {
          console.error("Failed to parse portfolio", e);
        }
      } else {
        setHoldings([]);
      }
    } else {
      setHoldings([]);
    }
  }, [user]);

  // Save portfolio to local storage when it changes
  useEffect(() => {
    if (user) {
      localStorage.setItem(`investro_portfolio_${user.email}`, JSON.stringify(holdings));
    }
  }, [holdings, user]);

  const buyStock = (symbol: string, name: string, price: number, quantity: number) => {
    setHoldings(prev => {
      const existing = prev.find(h => h.symbol === symbol);
      if (existing) {
        const totalCost = (existing.averagePrice * existing.quantity) + (price * quantity);
        const newQuantity = existing.quantity + quantity;
        const newAverage = totalCost / newQuantity;
        
        return prev.map(h => h.symbol === symbol ? {
          ...h,
          quantity: newQuantity,
          averagePrice: newAverage
        } : h);
      } else {
        return [...prev, { symbol, name, quantity, averagePrice: price }];
      }
    });
    toast({
      title: "Stock Purchased",
      description: `Bought ${quantity} shares of ${symbol} at ₹${price.toFixed(2)}`,
    });
  };

  const sellStock = (symbol: string, price: number, quantity: number) => {
    setHoldings(prev => {
      const existing = prev.find(h => h.symbol === symbol);
      if (!existing || existing.quantity < quantity) {
        toast({
          title: "Error",
          description: "Insufficient quantity to sell",
          variant: "destructive"
        });
        return prev;
      }

      const newQuantity = existing.quantity - quantity;
      
      toast({
        title: "Stock Sold",
        description: `Sold ${quantity} shares of ${symbol} at ₹${price.toFixed(2)}`,
      });

      if (newQuantity <= 0) {
        return prev.filter(h => h.symbol !== symbol);
      }

      return prev.map(h => h.symbol === symbol ? { ...h, quantity: newQuantity } : h);
    });
  };

  const getHolding = (symbol: string) => {
    return holdings.find(h => h.symbol === symbol);
  };

  const totalInvested = holdings.reduce((sum, h) => sum + (h.averagePrice * h.quantity), 0);
  
  const totalCurrentValue = (currentPrices: Record<string, number>) => {
    return holdings.reduce((sum, h) => {
      const currentPrice = currentPrices[h.symbol] || h.averagePrice;
      return sum + (currentPrice * h.quantity);
    }, 0);
  };

  return (
    <PortfolioContext.Provider value={{ holdings, buyStock, sellStock, getHolding, totalInvested, totalCurrentValue }}>
      {children}
    </PortfolioContext.Provider>
  );
}

export function usePortfolio() {
  const context = useContext(PortfolioContext);
  if (context === undefined) {
    throw new Error("usePortfolio must be used within a PortfolioProvider");
  }
  return context;
}
