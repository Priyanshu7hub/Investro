import { usePortfolio } from "@/context/PortfolioContext";
import { useMarket } from "@/context/MarketContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Link } from "wouter";
import { ArrowUpRight, PieChart } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Portfolio() {
  const { holdings, totalInvested, totalCurrentValue } = usePortfolio();
  const { stocks } = useMarket();

  // Create a map of current prices for easy lookup
  const currentPrices = stocks.reduce((acc, stock) => {
    acc[stock.symbol] = stock.price;
    return acc;
  }, {} as Record<string, number>);

  const currentValue = totalCurrentValue(currentPrices);
  const totalPL = currentValue - totalInvested;
  const isProfitable = totalPL >= 0;

  return (
    <div className="container py-8 px-4 md:px-6 space-y-8 animate-in fade-in duration-500">
      <h1 className="text-3xl font-display font-bold">Your Portfolio</h1>

      {/* Portfolio Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="border-border/50 bg-card/50 backdrop-blur-sm shadow-lg">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Invested</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-mono font-bold">₹{totalInvested.toFixed(2)}</div>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-card/50 backdrop-blur-sm shadow-lg">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Current Value</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-mono font-bold">₹{currentValue.toFixed(2)}</div>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-card/50 backdrop-blur-sm shadow-lg">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total P&L</CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-mono font-bold ${isProfitable ? 'text-primary' : 'text-destructive'}`}>
              {isProfitable ? '+' : ''}₹{totalPL.toFixed(2)}
            </div>
            <p className={`text-xs mt-1 ${isProfitable ? 'text-primary/80' : 'text-destructive/80'}`}>
              {totalInvested > 0 ? ((totalPL / totalInvested) * 100).toFixed(2) : '0.00'}% Return
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Holdings Table */}
      <Card className="border-border/50 bg-card/50 backdrop-blur-sm shadow-xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <PieChart className="h-5 w-5 text-primary" />
            Holdings
          </CardTitle>
        </CardHeader>
        <CardContent>
          {holdings.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <div className="bg-primary/5 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <PieChart className="h-8 w-8 text-primary/40" />
              </div>
              <p className="text-lg font-medium text-foreground mb-1">No stocks owned</p>
              <p className="text-sm mb-6">Your portfolio is currently empty. Start trading to see your holdings here.</p>
              <Link href="/dashboard">
                <Button variant="outline" className="border-primary/50 text-primary hover:bg-primary/10">
                  Explore Market
                </Button>
              </Link>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent border-border/50">
                  <TableHead>Symbol</TableHead>
                  <TableHead className="text-right">Qty</TableHead>
                  <TableHead className="text-right">Avg Price</TableHead>
                  <TableHead className="text-right">Cur Price</TableHead>
                  <TableHead className="text-right">Invested</TableHead>
                  <TableHead className="text-right">P&L</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {holdings.map((holding) => {
                  const currentPrice = currentPrices[holding.symbol] || holding.averagePrice;
                  const pl = (currentPrice - holding.averagePrice) * holding.quantity;
                  const plPercent = ((currentPrice - holding.averagePrice) / holding.averagePrice) * 100;
                  const isGain = pl >= 0;

                  return (
                    <TableRow key={holding.symbol} className="hover:bg-white/5 border-border/50">
                      <TableCell className="font-medium">
                        <div>{holding.symbol}</div>
                        <div className="text-xs text-muted-foreground">{holding.name}</div>
                      </TableCell>
                      <TableCell className="text-right font-mono">{holding.quantity}</TableCell>
                      <TableCell className="text-right font-mono">₹{holding.averagePrice.toFixed(2)}</TableCell>
                      <TableCell className="text-right font-mono">₹{currentPrice.toFixed(2)}</TableCell>
                      <TableCell className="text-right font-mono">₹{(holding.averagePrice * holding.quantity).toFixed(2)}</TableCell>
                      <TableCell className="text-right">
                        <div className={`font-mono font-medium ${isGain ? 'text-primary' : 'text-destructive'}`}>
                          {isGain ? '+' : ''}₹{pl.toFixed(2)}
                        </div>
                        <div className={`text-xs ${isGain ? 'text-primary/70' : 'text-destructive/70'}`}>
                          {plPercent.toFixed(2)}%
                        </div>
                      </TableCell>
                      <TableCell>
                        <Link href={`/stock/${holding.symbol}`} target="_blank">
                          <Button variant="ghost" size="icon" className="h-8 w-8 hover:text-primary">
                            <ArrowUpRight className="h-4 w-4" />
                          </Button>
                        </Link>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
