import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider, useAuth } from "@/context/AuthContext";
import { MarketProvider } from "@/context/MarketContext";
import { PortfolioProvider } from "@/context/PortfolioContext";
import { Navbar } from "@/components/Navbar";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Login from "@/pages/Login";
import Register from "@/pages/Register";
import Dashboard from "@/pages/Dashboard";
import Portfolio from "@/pages/Portfolio";
import StockDetail from "@/pages/StockDetail";

function ProtectedRoute({ component: Component, ...rest }: any) {
  const { user, isLoading } = useAuth();

  if (isLoading) return null;

  if (!user) {
    return <Redirect to="/login" />;
  }

  return <Component {...rest} />;
}

function Router() {
  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col font-sans">
      <Navbar />
      <main className="flex-1">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/login" component={Login} />
          <Route path="/register" component={Register} />
          
          <Route path="/dashboard">
            {(params) => <ProtectedRoute component={Dashboard} {...params} />}
          </Route>
          <Route path="/portfolio">
            {(params) => <ProtectedRoute component={Portfolio} {...params} />}
          </Route>
          <Route path="/stock/:symbol">
            {(params) => <ProtectedRoute component={StockDetail} {...params} />}
          </Route>
          
          <Route component={NotFound} />
        </Switch>
      </main>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <MarketProvider>
          <PortfolioProvider>
            <Router />
            <Toaster />
          </PortfolioProvider>
        </MarketProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
